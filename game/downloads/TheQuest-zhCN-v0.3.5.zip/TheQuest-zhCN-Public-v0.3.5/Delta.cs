// Original patch reconstruction code, MIT license; see LICENSES/MIT.txt.
// No game files or Windows font outlines are embedded in this source.
using System;
using System.IO;
using System.IO.Compression;
using System.Runtime.InteropServices;
using System.Security.Cryptography;

namespace QuestPublicPatch {
    public sealed class Step {
        public string Kind;
        public long SourceOffset;
        public long SourceLength;
        public string Data;
        public string Artifact;
        public string SourceSha256;
        public string TargetSha256;
        public string CompressedSha256;
        public long UncompressedLength;
        public long CompressedLength;
    }
    public static class Rebuild {
        private const int MaximumEntry = 64 * 1024 * 1024;
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        private static extern IntPtr LoadLibraryEx(string file, IntPtr unused, uint flags);
        [DllImport("kernel32.dll", CharSet = CharSet.Ansi, SetLastError = true)]
        private static extern IntPtr GetProcAddress(IntPtr library, string name);
        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool FreeLibrary(IntPtr library);
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate uint Bound(uint length);
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate int Deflate([In] byte[] source, uint sourceLength,
                                     [Out] byte[] target, uint targetCapacity);
        public static string HashBytes(byte[] bytes) {
            using (SHA256 algorithm = SHA256.Create()) {
                return BitConverter.ToString(algorithm.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant();
            }
        }
        private static string SafeArtifact(string root, string relative) {
            if (String.IsNullOrEmpty(relative) || Path.IsPathRooted(relative)) throw new InvalidDataException("Invalid artifact path.");
            string basePath = Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
            string result = Path.GetFullPath(Path.Combine(basePath, relative.Replace('/', Path.DirectorySeparatorChar)));
            if (!result.StartsWith(basePath, StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("Artifact path leaves package.");
            return result;
        }
        private static byte[] ReadExact(BinaryReader input, int count) {
            if (count < 0 || count > MaximumEntry) throw new InvalidDataException("Invalid entry length.");
            byte[] bytes = input.ReadBytes(count);
            if (bytes.Length != count) throw new EndOfStreamException("Truncated delta.");
            return bytes;
        }
        public static byte[] ApplyDelta(byte[] original, string deltaPath) {
            using (FileStream file = File.OpenRead(deltaPath))
            using (GZipStream gzip = new GZipStream(file, CompressionMode.Decompress))
            using (BinaryReader input = new BinaryReader(gzip)) {
                byte[] magic = ReadExact(input, 8);
                if (BitConverter.ToString(magic) != "51-5A-44-50-31-0D-0A-00") throw new InvalidDataException("Unsupported delta format.");
                long originalLength = input.ReadInt64();
                long targetLength = input.ReadInt64();
                string originalHash = BitConverter.ToString(ReadExact(input, 32)).Replace("-", "").ToLowerInvariant();
                string targetHash = BitConverter.ToString(ReadExact(input, 32)).Replace("-", "").ToLowerInvariant();
                if (originalLength != original.LongLength || HashBytes(original) != originalHash)
                    throw new InvalidDataException("Delta source checksum mismatch.");
                if (targetLength < 0 || targetLength > MaximumEntry) throw new InvalidDataException("Delta output exceeds entry limit.");
                byte[] target = new byte[(int)targetLength];
                long at = 0;
                for (;;) {
                    byte opcode = input.ReadByte();
                    if (opcode == 0) break;
                    if (opcode == 1) {
                        long offset = input.ReadInt64();
                        uint length = input.ReadUInt32();
                        if (offset < 0 || length == 0 || offset > original.LongLength - length || at > targetLength - length)
                            throw new InvalidDataException("Invalid COPY range.");
                        Buffer.BlockCopy(original, (int)offset, target, (int)at, (int)length);
                        at += length;
                    } else if (opcode == 2) {
                        uint length = input.ReadUInt32();
                        if (length == 0 || length > MaximumEntry || at > targetLength - length)
                            throw new InvalidDataException("Invalid literal range.");
                        byte[] literal = ReadExact(input, (int)length);
                        Buffer.BlockCopy(literal, 0, target, (int)at, (int)length);
                        at += length;
                    } else throw new InvalidDataException("Unknown delta opcode.");
                }
                if (at != targetLength || input.BaseStream.ReadByte() != -1 || HashBytes(target) != targetHash)
                    throw new InvalidDataException("Delta output checksum or boundary mismatch.");
                return target;
            }
        }
        private static byte[] InflateOriginal(FileStream source, Step step) {
            if (step.SourceOffset < 0 || step.SourceLength < 0 || step.SourceLength > MaximumEntry ||
                step.SourceOffset > source.Length - step.SourceLength)
                throw new InvalidDataException("Invalid compressed source range.");
            source.Position = step.SourceOffset;
            byte[] compressed = new byte[(int)step.SourceLength];
            int read = 0;
            while (read < compressed.Length) {
                int count = source.Read(compressed, read, compressed.Length - read);
                if (count == 0) throw new EndOfStreamException();
                read += count;
            }
            using (MemoryStream buffer = new MemoryStream(compressed, false))
            using (DeflateStream deflate = new DeflateStream(buffer, CompressionMode.Decompress))
            using (MemoryStream output = new MemoryStream()) {
                byte[] chunk = new byte[65536];
                for (;;) {
                    int count = deflate.Read(chunk, 0, chunk.Length);
                    if (count == 0) break;
                    if (output.Length + count > MaximumEntry) throw new InvalidDataException("Source entry too large.");
                    output.Write(chunk, 0, count);
                }
                byte[] original = output.ToArray();
                if (HashBytes(original) != step.SourceSha256) throw new InvalidDataException("Source entry checksum mismatch.");
                return original;
            }
        }
        public static void BuildArchive(string sourcePath, string outputPath, string packageRoot,
                                        string compressorPath, Step[] steps, long expectedLength) {
            IntPtr library = LoadLibraryEx(Path.GetFullPath(compressorPath), IntPtr.Zero, 8);
            if (library == IntPtr.Zero) throw new IOException("Cannot load patch compressor.");
            try {
                IntPtr boundPtr = GetProcAddress(library, "qz_bound");
                IntPtr deflatePtr = GetProcAddress(library, "qz_deflate");
                if (boundPtr == IntPtr.Zero || deflatePtr == IntPtr.Zero) throw new InvalidDataException("Invalid compressor exports.");
                Bound bound = (Bound)Marshal.GetDelegateForFunctionPointer(boundPtr, typeof(Bound));
                Deflate compress = (Deflate)Marshal.GetDelegateForFunctionPointer(deflatePtr, typeof(Deflate));
                using (FileStream source = File.OpenRead(sourcePath))
                using (FileStream output = new FileStream(outputPath, FileMode.CreateNew, FileAccess.Write, FileShare.None)) {
                    byte[] chunk = new byte[65536];
                    foreach (Step step in steps) {
                        if (step.Kind == "copy") {
                            if (step.SourceOffset < 0 || step.SourceLength <= 0 || step.SourceOffset > source.Length - step.SourceLength)
                                throw new InvalidDataException("Invalid archive COPY range.");
                            source.Position = step.SourceOffset;
                            long remaining = step.SourceLength;
                            while (remaining > 0) {
                                int count = source.Read(chunk, 0, (int)Math.Min(remaining, chunk.Length));
                                if (count == 0) throw new EndOfStreamException();
                                output.Write(chunk, 0, count); remaining -= count;
                            }
                        } else if (step.Kind == "literal") {
                            byte[] literal = Convert.FromBase64String(step.Data);
                            if (literal.Length > MaximumEntry) throw new InvalidDataException("Archive literal exceeds limit.");
                            output.Write(literal, 0, literal.Length);
                        } else if (step.Kind == "entry-delta" || step.Kind == "entry-new") {
                            byte[] target;
                            string artifact = SafeArtifact(packageRoot, step.Artifact);
                            if (step.Kind == "entry-delta") target = ApplyDelta(InflateOriginal(source, step), artifact);
                            else {
                                FileInfo info = new FileInfo(artifact);
                                if (info.Length > MaximumEntry) throw new InvalidDataException("New entry too large.");
                                target = File.ReadAllBytes(artifact);
                            }
                            if (target.LongLength != step.UncompressedLength || HashBytes(target) != step.TargetSha256)
                                throw new InvalidDataException("Target entry checksum mismatch.");
                            uint capacity = bound((uint)target.Length);
                            if (capacity < target.Length || capacity > MaximumEntry + MaximumEntry / 100)
                                throw new InvalidDataException("Invalid compressor bound.");
                            byte[] compressed = new byte[capacity];
                            int length = compress(target, (uint)target.Length, compressed, capacity);
                            if (length < 0 || length != step.CompressedLength) throw new InvalidDataException("Compression length mismatch.");
                            byte[] actual = new byte[length];
                            Buffer.BlockCopy(compressed, 0, actual, 0, length);
                            if (HashBytes(actual) != step.CompressedSha256) throw new InvalidDataException("Compression checksum mismatch.");
                            output.Write(actual, 0, actual.Length);
                        } else throw new InvalidDataException("Unknown archive instruction.");
                        if (output.Position > expectedLength) throw new InvalidDataException("Archive exceeds expected length.");
                    }
                    if (output.Length != expectedLength) throw new InvalidDataException("Archive length mismatch.");
                    output.Flush(true);
                }
            } finally { FreeLibrary(library); }
        }
    }
}
