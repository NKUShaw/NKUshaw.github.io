﻿param(
    [ValidateSet('Install','Restore','Status')][string]$Action = 'Status',
    [string]$GamePath
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2
$stageRoot = $null
$operationLock = $null
$stageFiles = New-Object 'System.Collections.Generic.List[string]'
$allowed = @('data.pak','d3d9.dll','expansions/isle.pak')

function Hash([string]$Path) {
    $stream = [IO.File]::OpenRead($Path)
    $algorithm = [Security.Cryptography.SHA256]::Create()
    try { return [BitConverter]::ToString($algorithm.ComputeHash($stream)).Replace('-', '').ToLowerInvariant() }
    finally { $stream.Dispose(); $algorithm.Dispose() }
}
function SafePath([string]$Root, [string]$Relative) {
    if (-not $Relative -or [IO.Path]::IsPathRooted($Relative)) { throw '无效的补丁相对路径。' }
    $base = [IO.Path]::GetFullPath($Root).TrimEnd([char[]]@('\','/')) + '\'
    $result = [IO.Path]::GetFullPath((Join-Path $base $Relative.Replace('/','\')))
    if (-not $result.StartsWith($base,[StringComparison]::OrdinalIgnoreCase)) { throw '补丁路径超出指定目录。' }
    return $result
}
function WriteState($Value, [switch]$Initial) {
    $temp = Join-Path $backupRoot ('state-' + [Guid]::NewGuid().ToString('N') + '.tmp')
    $Value | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $temp -Encoding UTF8
    if (-not $Initial -and [IO.File]::Exists($statePath)) { [IO.File]::Replace($temp,$statePath,[System.Management.Automation.Language.NullString]::Value) }
    else { [IO.File]::Move($temp,$statePath) }
}
function PutAtomic([string]$Staged,[string]$Target) {
    if ([IO.File]::Exists($Target)) { [IO.File]::Replace($Staged,$Target,[System.Management.Automation.Language.NullString]::Value) }
    else { [IO.File]::Move($Staged,$Target) }
}
function MakeStage {
    $script:stageRoot = Join-Path (Split-Path $gameRoot -Parent) ('.quest-zhcn-public-work-' + [Guid]::NewGuid().ToString('N'))
    if (Test-Path -LiteralPath $script:stageRoot) { throw '临时目录已经存在。' }
    New-Item -ItemType Directory -Path $script:stageRoot | Out-Null
}
function DetectGame {
    $candidates = @()
    if (Test-Path -LiteralPath (Join-Path $PSScriptRoot 'TheQuest.exe') -PathType Leaf) { $candidates += $PSScriptRoot }
    $steamRoots = @()
    foreach ($key in @('HKCU:\Software\Valve\Steam','HKLM:\SOFTWARE\WOW6432Node\Valve\Steam','HKLM:\SOFTWARE\Valve\Steam')) {
        $props = Get-ItemProperty -LiteralPath $key -ErrorAction SilentlyContinue
        if ($props) {
            if ($props.PSObject.Properties.Name -contains 'SteamPath' -and $props.SteamPath) { $steamRoots += $props.SteamPath }
            if ($props.PSObject.Properties.Name -contains 'InstallPath' -and $props.InstallPath) { $steamRoots += $props.InstallPath }
        }
    }
    if (${env:ProgramFiles(x86)}) { $steamRoots += (Join-Path ${env:ProgramFiles(x86)} 'Steam') }
    foreach ($steam in @($steamRoots | Select-Object -Unique)) {
        $libraries = @($steam)
        $vdf = Join-Path $steam 'steamapps\libraryfolders.vdf'
        if (Test-Path -LiteralPath $vdf -PathType Leaf) {
            $text = Get-Content -LiteralPath $vdf -Raw
            foreach ($match in [regex]::Matches($text,'"path"\s+"([^"\r\n]+)"')) { $libraries += $match.Groups[1].Value.Replace('\\','\') }
        }
        foreach ($library in $libraries) {
            $folder = Join-Path $library 'steamapps\common\The Quest'
            if (Test-Path -LiteralPath (Join-Path $folder 'TheQuest.exe') -PathType Leaf) { $candidates += $folder }
        }
    }
    $found = @($candidates | ForEach-Object { [IO.Path]::GetFullPath($_).TrimEnd('\') } | Select-Object -Unique)
    if ($found.Count -eq 1) { return $found[0] }
    Add-Type -AssemblyName System.Windows.Forms
    $dialog = New-Object System.Windows.Forms.OpenFileDialog
    $dialog.Title = '请选择 Steam 游戏目录中的 TheQuest.exe'
    $dialog.Filter = 'TheQuest.exe|TheQuest.exe'
    $dialog.CheckFileExists = $true
    try {
        if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { throw '已取消选择游戏目录。' }
        return (Split-Path $dialog.FileName -Parent)
    } finally { $dialog.Dispose() }
}
try {
    $manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($manifest.version -ne '0.3.5-public') { throw '补丁清单版本不受支持。' }
    if (-not $GamePath) { $GamePath = DetectGame }
    $gameRoot = [IO.Path]::GetFullPath($GamePath).TrimEnd([char[]]@('\','/'))
    $exePath = Join-Path $gameRoot 'TheQuest.exe'
    $backupRoot = $gameRoot + '.quest-zhcn-public-backup'
    $statePath = Join-Path $backupRoot 'state.json'
    if (-not (Test-Path -LiteralPath $exePath -PathType Leaf)) { throw '目录中未找到 TheQuest.exe。' }
    foreach ($file in $manifest.files) {
        if ($file.path -notin $allowed) { throw '清单包含不支持的游戏文件。' }
    }
    if (@($manifest.files).Count -ne 3 -or @($manifest.files.path | Select-Object -Unique).Count -ne 3) { throw '补丁文件清单不完整。' }
    if ($Action -eq 'Status') {
        Write-Host ('游戏目录：' + $gameRoot)
        if (Test-Path -LiteralPath $statePath -PathType Leaf) {
            $status = Get-Content -LiteralPath $statePath -Raw -Encoding UTF8 | ConvertFrom-Json
            Write-Host ('公开版补丁记录：' + $status.version + ' / ' + $status.status)
            foreach ($entry in $status.entries) {
                if ($entry.path -notin $allowed) { throw '安装记录中的路径无效。' }
                $target = SafePath $gameRoot $entry.path
                $matches = (Test-Path -LiteralPath $target -PathType Leaf) -and ((Hash $target) -eq $entry.installedSha256)
                Write-Host ($entry.path + ': ' + $(if ($matches) { '已安装且校验通过' } else { '文件状态与安装记录不同' }))
            }
        } else { Write-Host '没有本公开版补丁的安装记录。' }
        exit 0
    }
    $running = @(Get-Process -Name TheQuest -ErrorAction SilentlyContinue | Where-Object {
        -not $_.Path -or [IO.Path]::GetFullPath($_.Path) -eq $exePath
    })
    if ($running.Count) { throw '请先退出 The Quest，再安装或恢复。' }
    New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null
    try { $operationLock = [IO.File]::Open((Join-Path $backupRoot '.operation.lock'),[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None) }
    catch { throw '已有安装或恢复操作正在运行，请等待它完成。' }
    if ($Action -eq 'Restore') {
        if (-not (Test-Path -LiteralPath $statePath -PathType Leaf)) { Write-Host '没有需要恢复的安装记录。'; exit 0 }
        $state = Get-Content -LiteralPath $statePath -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($state.version -ne $manifest.version -or $state.gameRoot -ne $gameRoot) { throw '备份不属于这个版本或游戏目录。' }
        $seen = @()
        foreach ($entry in $state.entries) {
            if ($entry.path -notin $allowed -or $entry.path -in $seen) { throw '安装记录包含无效或重复路径。' }
            $seen += $entry.path
            $definition = @($manifest.files | Where-Object { $_.path -eq $entry.path })[0]
            if ($entry.installedSha256 -ne $definition.targetSha256) { throw '安装记录目标校验值不匹配。' }
            if ($entry.originalExists) {
                if ($entry.path -eq 'd3d9.dll' -or $entry.originalSha256 -ne $definition.sourceSha256) { throw '安装记录原版校验值不匹配。' }
                $backup = SafePath $backupRoot $entry.path
                if (-not (Test-Path -LiteralPath $backup -PathType Leaf) -or (Hash $backup) -ne $entry.originalSha256) { throw ('备份缺失或损坏：' + $entry.path) }
            } elseif ($entry.path -ne 'd3d9.dll') { throw '安装记录的原版状态无效。' }
            $target = SafePath $gameRoot $entry.path
            if (Test-Path -LiteralPath $target -PathType Leaf) {
                $current = Hash $target
                if ($current -ne $entry.installedSha256 -and (-not $entry.originalExists -or $current -ne $entry.originalSha256)) {
                    throw ('文件在安装后被更新或修改，已保留：' + $entry.path + '。恢复前请自行处理该改动。')
                }
            } elseif (Test-Path -LiteralPath $target) { throw ('目标不是普通文件：' + $entry.path) }
        }
        if ('data.pak' -notin $seen -or 'd3d9.dll' -notin $seen) { throw '安装记录缺少必要文件。' }
        MakeStage
        foreach ($entry in $state.entries) {
            if ($entry.originalExists) {
                $staged = SafePath $stageRoot $entry.path
                $stageFiles.Add($staged)
                New-Item -ItemType Directory -Path (Split-Path $staged -Parent) -Force | Out-Null
                [IO.File]::Copy((SafePath $backupRoot $entry.path),$staged)
                if ((Hash $staged) -ne $entry.originalSha256) { throw '恢复副本校验失败。' }
            }
        }
        foreach ($entry in $state.entries) {
            $target = SafePath $gameRoot $entry.path
            if ($entry.originalExists) { PutAtomic (SafePath $stageRoot $entry.path) $target }
            elseif ([IO.File]::Exists($target)) { [IO.File]::Delete($target) }
        }
        foreach ($entry in $state.entries) {
            $target = SafePath $gameRoot $entry.path
            if ($entry.originalExists -and (Hash $target) -ne $entry.originalSha256) { throw '恢复后的原版校验失败，备份仍保留。' }
            if (-not $entry.originalExists -and (Test-Path -LiteralPath $target)) { throw '补丁模块未能移除。' }
        }
        [IO.File]::Move($statePath,(Join-Path $backupRoot ('restored-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [Guid]::NewGuid().ToString('N') + '.json')))
        Write-Host '英文原版已恢复，原始备份仍保留；存档未改动。'
        exit 0
    }
    if (-not $manifest.installable) { throw '此公开包尚未启用安装。' }
    if (Test-Path -LiteralPath $statePath) { throw '已有本公开版安装记录。请先运行 Restore.cmd，再安装。' }
    if ((Hash $exePath) -ne $manifest.exeSha256) { throw '游戏程序版本不匹配。本包仅适用于已核对的 Steam The Quest v1.9.7。' }
    $selected = @()
    foreach ($file in $manifest.files) {
        $target = SafePath $gameRoot $file.path
        if ($file.optional -and -not (Test-Path -LiteralPath $target)) {
            Write-Host '未安装冰火之岛，跳过该资料片，只安装主游戏汉化。'
            continue
        }
        if ($file.PSObject.Properties.Name -contains 'sourceAbsent' -and $file.sourceAbsent) {
            if (Test-Path -LiteralPath $target) { throw '已有 d3d9.dll 模组，已保留。若是旧汉化，请先用旧版恢复脚本还原。' }
        } elseif (-not (Test-Path -LiteralPath $target -PathType Leaf) -or (Hash $target) -ne $file.sourceSha256) {
            throw ('原版资源版本不匹配：' + $file.path + '。请先恢复原版或在 Steam 校验游戏文件。')
        }
        $selected += $file
    }
    foreach ($property in $manifest.artifactHashes.PSObject.Properties) {
        $artifact = SafePath $PSScriptRoot $property.Name
        if (-not (Test-Path -LiteralPath $artifact -PathType Leaf) -or (Hash $artifact) -ne $property.Value) { throw ('下载文件缺失或校验失败：' + $property.Name) }
    }
    if (-not ('QuestPublicPatch.Rebuild' -as [type])) { Add-Type -Path (Join-Path $PSScriptRoot 'Delta.cs') }
    $native = Join-Path $PSScriptRoot $(if ([Environment]::Is64BitProcess) { 'native\qzlib-x64.dll' } else { 'native\qzlib-x86.dll' })
    MakeStage
    foreach ($file in $selected) {
        Write-Host ('重建并核验：' + $file.path)
        $staged = SafePath $stageRoot $file.path
        $stageFiles.Add($staged)
        New-Item -ItemType Directory -Path (Split-Path $staged -Parent) -Force | Out-Null
        if ($file.PSObject.Properties.Name -contains 'component') {
            [IO.File]::Copy((SafePath $PSScriptRoot $file.component),$staged)
        } else {
            $recipe = Get-Content -LiteralPath (SafePath $PSScriptRoot $file.recipe) -Raw -Encoding UTF8 | ConvertFrom-Json
            if ($recipe.format -ne 'QuestPublicArchive1' -or $recipe.sourceSha256 -ne $file.sourceSha256 -or $recipe.targetSha256 -ne $file.targetSha256 -or $recipe.targetLength -ne $file.targetBytes) { throw '差量配方与清单不匹配。' }
            $steps = @()
            foreach ($item in $recipe.steps) {
                $step = New-Object QuestPublicPatch.Step
                foreach ($property in $item.PSObject.Properties) { $step.($property.Name) = $property.Value }
                $steps += $step
            }
            [QuestPublicPatch.Rebuild]::BuildArchive((SafePath $gameRoot $file.path),$staged,$PSScriptRoot,$native,[QuestPublicPatch.Step[]]$steps,[long]$file.targetBytes)
        }
        if ((Get-Item -LiteralPath $staged).Length -ne $file.targetBytes -or (Hash $staged) -ne $file.targetSha256) { throw ('重建结果校验失败：' + $file.path) }
    }
    $entries = @()
    foreach ($file in $selected) {
        $target = SafePath $gameRoot $file.path
        $exists = [IO.File]::Exists($target)
        $entry = [ordered]@{path=$file.path;originalExists=$exists;originalSha256=$null;installedSha256=$file.targetSha256}
        if ($exists) {
            if ((Hash $target) -ne $file.sourceSha256) { throw '重建期间原版资源已变化，停止安装。' }
            $entry.originalSha256 = $file.sourceSha256
            $backup = SafePath $backupRoot $file.path
            New-Item -ItemType Directory -Path (Split-Path $backup -Parent) -Force | Out-Null
            if (Test-Path -LiteralPath $backup) {
                if (-not (Test-Path -LiteralPath $backup -PathType Leaf) -or (Hash $backup) -ne $file.sourceSha256) { throw ('已有备份不匹配，未覆盖：' + $file.path) }
            } else { [IO.File]::Copy($target,$backup) }
            if ((Hash $backup) -ne $file.sourceSha256) { throw '原版备份校验失败。' }
        }
        $entries += $entry
    }
    New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null
    $state = [ordered]@{version=$manifest.version;gameRoot=$gameRoot;status='installing';installedAt=(Get-Date -Format o);entries=$entries}
    WriteState $state -Initial
    try {
        foreach ($file in $selected) {
            $target = SafePath $gameRoot $file.path
            if ($file.PSObject.Properties.Name -contains 'sourceAbsent' -and $file.sourceAbsent -and (Test-Path -LiteralPath $target)) { throw '安装期间出现另一个 d3d9.dll，停止替换。' }
            if ($file.PSObject.Properties.Name -contains 'sourceSha256' -and (Hash $target) -ne $file.sourceSha256) { throw '安装期间原版资源变化，停止替换。' }
            if ($file.PSObject.Properties.Name -contains 'sourceAbsent' -and $file.sourceAbsent) { [IO.File]::Move((SafePath $stageRoot $file.path),$target) }
            else { PutAtomic (SafePath $stageRoot $file.path) $target }
        }
        foreach ($file in $selected) { if ((Hash (SafePath $gameRoot $file.path)) -ne $file.targetSha256) { throw '安装后校验失败。' } }
        $state.status = 'installed'
        WriteState $state
    } catch {
        $installError = $_
        try {
            foreach ($entry in $entries) {
                $target = SafePath $gameRoot $entry.path
                if ([IO.File]::Exists($target)) {
                    $current = Hash $target
                    if ($current -ne $entry.installedSha256 -and (-not $entry.originalExists -or $current -ne $entry.originalSha256)) { throw '回滚时发现外部修改，保留该文件和安装记录。' }
                }
            }
            foreach ($entry in $entries) {
                $target = SafePath $gameRoot $entry.path
                if ($entry.originalExists) {
                    $recovery = Join-Path $stageRoot ([Guid]::NewGuid().ToString('N') + '.restore')
                    $stageFiles.Add($recovery)
                    [IO.File]::Copy((SafePath $backupRoot $entry.path),$recovery)
                    if ((Hash $recovery) -ne $entry.originalSha256) { throw '回滚副本校验失败，保留安装记录。' }
                    PutAtomic $recovery $target
                } elseif ([IO.File]::Exists($target)) { [IO.File]::Delete($target) }
            }
            foreach ($entry in $entries) {
                $target = SafePath $gameRoot $entry.path
                if ($entry.originalExists -and (Hash $target) -ne $entry.originalSha256) { throw '回滚后校验失败，保留备份。' }
                if (-not $entry.originalExists -and (Test-Path -LiteralPath $target)) { throw '回滚后模块仍存在。' }
            }
            [IO.File]::Move($statePath,(Join-Path $backupRoot ('failed-restored-' + [Guid]::NewGuid().ToString('N') + '.json')))
            Write-Host '安装未完成，已从校验备份回滚到原版。'
        } catch { Write-Host '安装未完成，备份与安装记录已保留；请运行 Restore.cmd 检查恢复。' -ForegroundColor Yellow }
        throw $installError
    }
    Write-Host 'v0.3.5-public 已安装。请从 Steam 启动游戏。'
    Write-Host '恢复英文：先退出游戏，再双击 Restore.cmd。存档未改动。'
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    if ($_.Exception -is [UnauthorizedAccessException] -or $_.Exception.InnerException -is [UnauthorizedAccessException]) { Write-Host '权限不足：可右键安装或恢复脚本，以管理员身份运行。' }
    exit 1
} finally {
    if ($operationLock) { $operationLock.Dispose() }
    if ($stageRoot -and (Test-Path -LiteralPath $stageRoot)) {
        $parent = [IO.Path]::GetFullPath((Split-Path $gameRoot -Parent)).TrimEnd('\') + '\'
        $resolved = [IO.Path]::GetFullPath($stageRoot)
        if ($resolved.StartsWith($parent,[StringComparison]::OrdinalIgnoreCase) -and (Split-Path $resolved -Leaf) -match '^\.quest-zhcn-public-work-[0-9a-f]{32}$') {
            foreach ($file in @($stageFiles | Select-Object -Unique)) {
                $full = [IO.Path]::GetFullPath($file)
                if ($full.StartsWith($resolved + '\',[StringComparison]::OrdinalIgnoreCase)) {
                    try { [IO.File]::Delete($full) } catch { }
                }
            }
            # Only known empty directories are removed; unknown files are preserved.
            foreach ($directory in @((Join-Path $resolved 'expansions'),$resolved)) {
                try { [IO.Directory]::Delete($directory,$false) } catch { }
            }
        }
    }
}
