/* The Quest public patch compressor bridge, original code under MIT.
   zlib itself is unmodified and remains under its accompanying license. */
#include "zlib.h"
#include <stdint.h>
#include <string.h>
#if defined(_WIN32)
#define EXPORT __declspec(dllexport)
#else
#define EXPORT
#endif
EXPORT uint32_t qz_bound(uint32_t length) { return (uint32_t)compressBound(length); }
EXPORT int qz_deflate(const unsigned char *source, uint32_t source_length,
                     unsigned char *target, uint32_t target_capacity) {
    z_stream stream;
    memset(&stream, 0, sizeof(stream));
    int status = deflateInit2(&stream, 6, Z_DEFLATED, -15, 8, Z_DEFAULT_STRATEGY);
    if (status != Z_OK) return -1;
    stream.next_in = (Bytef *)source;
    stream.avail_in = source_length;
    stream.next_out = target;
    stream.avail_out = target_capacity;
    status = deflate(&stream, Z_FINISH);
    int written = status == Z_STREAM_END && stream.avail_in == 0 ? (int)stream.total_out : -2;
    deflateEnd(&stream);
    return written;
}
